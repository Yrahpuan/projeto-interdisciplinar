export enum NiveisDeRisco {
    vermelho,
    laranja,
    amarelo,
    verde,
    azul
}

export const LimiteDeSenhas = [0, 999, 1999, 2999, 3999];

export const LimiteDeTempo = [0, 10, 60, 120, 240];
