import * as fs from "fs";
import path from "path";
import { ModeloPaciente } from "./models";

export const pacientesDatabaseFileName = path.resolve(__dirname, "../databases/registroDePacientes.json");
export const filaFileName = path.resolve(__dirname, "../databases/fila.json");
export const registroTriagemFileName = path.resolve(__dirname, "../databases/registroDeTriagens.json");

export function carregarJSON(path: string): any[] {
    if (!fs.existsSync(path)) return [];
        return JSON.parse(fs.readFileSync(path, "utf-8"));
}

export function salvarJSON(path: string, data: any): void {
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
}

export function procurarPacientePorId(id: number): ModeloPaciente | undefined {
    const pacientes = carregarJSON(pacientesDatabaseFileName);
    return pacientes.find(p => p.id === id);
    }

export function procurarPacientePorCpf(cpf: string): ModeloPaciente | undefined {
    const pacientes = carregarJSON(pacientesDatabaseFileName);
    return pacientes.find(p => p.cpf.includes(cpf));
    }