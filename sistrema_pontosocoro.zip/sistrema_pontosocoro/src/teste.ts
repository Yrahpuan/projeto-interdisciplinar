import { ControleDePrioridade } from "./ControleDePrioridade";
import { NivelsDeRisco } from "./informacoesDeRisco";

// Criando a fila principal que gerencia todos os heaps por cor
const fila = new ControleDePrioridade();

// Adicionando pacientes simulados com diferentes tempos de chegada
fila.adicionar({
  id: 1,
  senha: 100,
  risco: NivelsDeRisco.azul,
  horarioDeChegada: new Date(Date.now() - 235 * 60000) // chegou há 235 minutos
});

fila.adicionar({
  id: 2,
  senha: 200,
  risco: NivelsDeRisco.laranja,
  horarioDeChegada: new Date(Date.now() - 5 * 60000) // chegou há 5 minutos
});

fila.adicionar({
  id: 3,
  senha: 300,
  risco: NivelsDeRisco.amarelo,
  horarioDeChegada: new Date(Date.now() - 59 * 60000) // chegou há 59 minutos
});

fila.adicionar({
  id: 4,
  senha: 400,
  risco: NivelsDeRisco.verde,
  horarioDeChegada: new Date(Date.now() - 100 * 60000) // chegou há 100 minutos
});

fila.adicionar({
  id: 5,
  senha: 500,
  risco: NivelsDeRisco.vermelho,
  horarioDeChegada: new Date(Date.now()) // chegou agora
});

fila.adicionar({
    id: 6,
    senha: 101,
    risco: NivelsDeRisco.azul,
    horarioDeChegada: new Date(Date.now() - 235 * 60000) // chegou há 235 min
  });
  
  fila.adicionar({
    id: 7,
    senha: 100,
    risco: NivelsDeRisco.azul,
    horarioDeChegada: new Date(Date.now() - 235 * 60000) // mesmo tempo
  });

// Extraindo os atendimentos em ordem de prioridade real (baseada no tempo restante)
while (fila.temElementos()) {
  const proximo = fila.proximo();
  if (proximo) {
    console.log(`Chamando paciente ID ${proximo.id}, senha ${proximo.senha}, risco ${NivelsDeRisco[proximo.risco]}`);
  }
}
