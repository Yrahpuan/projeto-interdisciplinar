import { NivelsDeRisco, LimiteDeTempo } from "./informacoesDeRisco";
import { MinHeap } from "./Heap";

export type ModeloFilaDePrioridade = {
  id: number;
  senha: number;
  risco: NivelsDeRisco;
  horarioDeChegada: Date;
};

export class ControleDePrioridade {
  public readonly heaps: MinHeap[] = [];

  constructor() {
    for (let risco = 0; risco <= 4; risco++) {
      this.heaps[risco] = new MinHeap();
    }
  }

  adicionar(modelo: ModeloFilaDePrioridade): void {
    this.heaps[modelo.risco].insert(modelo);
  }

  proximo(): ModeloFilaDePrioridade | undefined {
    let candidato: ModeloFilaDePrioridade | undefined;
    let menorTempoRestante = Infinity;

    for (const fila of this.heaps) {
      const atual = fila.peek();
      if (atual) {
        const agora = new Date();
        const tempoDecorrido = (agora.getTime() - atual.horarioDeChegada.getTime()) / 60000;
        const restante = LimiteDeTempo[atual.risco] - tempoDecorrido;

        if (restante < menorTempoRestante) {
          menorTempoRestante = restante;
          candidato = atual;
        }
      }
    }

    if (!candidato) return undefined;

    return this.heaps[candidato.risco].extractMin();
  }

  temElementos(): boolean {
    return this.heaps.some(fila => !fila.isEmpty());
  }

  mostrarFilas(): void {
    console.log("\n=== FILAS DE PRIORIDADE POR RISCO ===");
    Object.entries(this.heaps).forEach(([risco, heap]) => {
      console.log(`\nFila ${NivelsDeRisco[parseInt(risco)]}:`);
      heap.mostrarConteudo();
    });
  }
  
}
