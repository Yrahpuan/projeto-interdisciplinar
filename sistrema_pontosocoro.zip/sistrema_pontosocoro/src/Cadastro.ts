import * as fs from "fs";
import { ModeloPaciente } from "./Paciente";

export class Cadastro {
    private baseDeDados: ModeloPaciente[] = [];

    constructor() {
        this.carregarBaseDeDados();
    }

    cadastrarPaciente(id: number, cpf: string, nome: string, idade: number): ModeloPaciente {
        if (this.baseDeDados.some(p => p.cpf === cpf)) {
            throw new Error("Não é permitido cadastrar duas pessoas com o mesmo CPF.");
        }

        const novoPaciente: ModeloPaciente = { id, cpf, nome, idade };
        this.baseDeDados.push(novoPaciente);
        this.salvarBaseDeDados();
        return novoPaciente;
    }

    procurarPacientePorId(id: number): ModeloPaciente | undefined {
        return this.baseDeDados.find(p => p.id === id);
    }

    procurarPacientePorCpf(cpf: string): ModeloPaciente | undefined {
        return this.baseDeDados.find(p => p.cpf.includes(cpf));
    }

    mandarParaTriagem(paciente: ModeloPaciente): void {
        const fila = this.carregarJSON("./database/pacientesParaTriagem.json");
        fila.push(paciente);
        this.salvarJSON("./database/pacientesParaTriagem.json", fila);
    }

    private salvarBaseDeDados(): void {
        this.salvarJSON("../database/baseDeDados.json", this.baseDeDados);
    }

    private carregarBaseDeDados(): void {
        this.baseDeDados = this.carregarJSON("./database/baseDeDados.json");
    }

    private carregarJSON(path: string): any[] {
        if (!fs.existsSync(path)) return [];
        return JSON.parse(fs.readFileSync(path, "utf-8"));
    }

    private salvarJSON(path: string, data: any): void {
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
    }
}
