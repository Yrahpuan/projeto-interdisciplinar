export type ModeloPaciente = {
    id: number;
    cpf: string;
    nome: string;
    idade: number;
};

export class Paciente {
    constructor(
        protected id: number,
        protected cpf: string,
        protected nome: string,
        protected idade: number
    ) {}

    getId(): number {
        return this.id;
    }

    getCpf(): string {
        return this.cpf;
    }

    toJSON(): ModeloPaciente {
        return {
            id: this.id,
            cpf: this.cpf,
            nome: this.nome,
            idade: this.idade
        };
    }

    static fromModel(model: ModeloPaciente): Paciente {
        return new Paciente(model.id, model.cpf, model.nome, model.idade);
    }
}
