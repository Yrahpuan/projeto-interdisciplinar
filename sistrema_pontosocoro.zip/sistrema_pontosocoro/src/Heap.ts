import { ModeloFilaDePrioridade } from "./ControleDePrioridade";
import { LimiteDeTempo } from "./informacoesDeRisco";

export class MinHeap {
  readonly heap: ModeloFilaDePrioridade[] = [];

  private parent(index: number): number {
    return Math.floor((index - 1) / 2);
  }

  private leftChild(index: number): number {
    return 2 * index + 1;
  }

  private rightChild(index: number): number {
    return 2 * index + 2;
  }
  public mostrarConteudo(): void {
    console.log("Heap:");
    this.heap.forEach((item, index) => {
      console.log(
        `  [${index}] ID: ${item.id}, Senha: ${item.senha}, Risco: ${item.risco}, Chegada: ${item.horarioDeChegada.toLocaleString()}`
      );
    });
  }
  
  private tempoRestante(item: ModeloFilaDePrioridade): number {
    const agora = new Date();
    const decorrido = (agora.getTime() - item.horarioDeChegada.getTime()) / 60000;
    return LimiteDeTempo[item.risco] - decorrido;
  }

  private compare(a: ModeloFilaDePrioridade, b: ModeloFilaDePrioridade): number {
    const agora = new Date();
  
    const decorridoA = (agora.getTime() - a.horarioDeChegada.getTime()) / 60000;
    const restanteA = LimiteDeTempo[a.risco] - decorridoA;
  
    const decorridoB = (agora.getTime() - b.horarioDeChegada.getTime()) / 60000;
    const restanteB = LimiteDeTempo[b.risco] - decorridoB;
  
    if (restanteA !== restanteB) {
      return restanteA - restanteB;
    }
  
    // Desempate: quem chegou antes
    if (a.horarioDeChegada.getTime() !== b.horarioDeChegada.getTime()) {
      return a.horarioDeChegada.getTime() - b.horarioDeChegada.getTime();
    }
  
  horarioDeChegada: Date;
    // Desempate final: menor número de senha
    return a.senha - b.senha;
  }  

  insert(value: ModeloFilaDePrioridade): void {
    this.heap.push(value);
    this.heapifyUp(this.heap.length - 1);
  }

  extractMin(): ModeloFilaDePrioridade | undefined {
    if (this.isEmpty()) return undefined;
    if (this.heap.length === 1) return this.heap.pop();

    const min = this.heap[0];
    this.heap[0] = this.heap.pop()!;
    this.heapifyDown(0);
    return min;
  }

  peek(): ModeloFilaDePrioridade | undefined {
    return this.heap[0];
  }

  isEmpty(): boolean {
    return this.heap.length === 0;
  }

  private heapifyUp(index: number): void {
    while (
      index > 0 &&
      this.compare(this.heap[index], this.heap[this.parent(index)]) < 0
    ) {
      this.swap(index, this.parent(index));
      index = this.parent(index);
    }
  }

  private heapifyDown(index: number): void {
    let smallest = index;
    const left = this.leftChild(index);
    const right = this.rightChild(index);

    if (
      left < this.heap.length &&
      this.compare(this.heap[left], this.heap[smallest]) < 0
    ) {
      smallest = left;
    }

    if (
      right < this.heap.length &&
      this.compare(this.heap[right], this.heap[smallest]) < 0
    ) {
      smallest = right;
    }

    if (smallest !== index) {
      this.swap(index, smallest);
      this.heapifyDown(smallest);
    }
  }

  private swap(i: number, j: number): void {
    [this.heap[i], this.heap[j]] = [this.heap[j], this.heap[i]];
  }
}
