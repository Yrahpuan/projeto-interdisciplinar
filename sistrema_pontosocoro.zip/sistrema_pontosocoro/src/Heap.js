"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MinHeap = void 0;
var informacoesDeRisco_1 = require("./informacoesDeRisco");
var MinHeap = /** @class */ (function () {
    function MinHeap() {
        this.heap = [];
    }
    MinHeap.prototype.parent = function (index) {
        return Math.floor((index - 1) / 2);
    };
    MinHeap.prototype.leftChild = function (index) {
        return 2 * index + 1;
    };
    MinHeap.prototype.rightChild = function (index) {
        return 2 * index + 2;
    };
    MinHeap.prototype.tempoRestante = function (item) {
        var agora = new Date();
        var decorrido = (agora.getTime() - item.horarioDeChegada.getTime()) / 60000;
        return informacoesDeRisco_1.LimiteDeTempo[item.risco] - decorrido;
    };
    MinHeap.prototype.compare = function (a, b) {
        var agora = new Date();
        var decorridoA = (agora.getTime() - a.horarioDeChegada.getTime()) / 60000;
        var restanteA = informacoesDeRisco_1.LimiteDeTempo[a.risco] - decorridoA;
        var decorridoB = (agora.getTime() - b.horarioDeChegada.getTime()) / 60000;
        var restanteB = informacoesDeRisco_1.LimiteDeTempo[b.risco] - decorridoB;
        if (restanteA !== restanteB) {
            return restanteA - restanteB;
        }
        // Desempate: quem chegou antes
        if (a.horarioDeChegada.getTime() !== b.horarioDeChegada.getTime()) {
            return a.horarioDeChegada.getTime() - b.horarioDeChegada.getTime();
        }
        // Desempate final: menor número de senha
        return a.senha - b.senha;
    };
    MinHeap.prototype.insert = function (value) {
        this.heap.push(value);
        this.heapifyUp(this.heap.length - 1);
    };
    MinHeap.prototype.extractMin = function () {
        if (this.isEmpty())
            return undefined;
        if (this.heap.length === 1)
            return this.heap.pop();
        var min = this.heap[0];
        this.heap[0] = this.heap.pop();
        this.heapifyDown(0);
        return min;
    };
    MinHeap.prototype.peek = function () {
        return this.heap[0];
    };
    MinHeap.prototype.isEmpty = function () {
        return this.heap.length === 0;
    };
    MinHeap.prototype.heapifyUp = function (index) {
        while (index > 0 &&
            this.compare(this.heap[index], this.heap[this.parent(index)]) < 0) {
            this.swap(index, this.parent(index));
            index = this.parent(index);
        }
    };
    MinHeap.prototype.heapifyDown = function (index) {
        var smallest = index;
        var left = this.leftChild(index);
        var right = this.rightChild(index);
        if (left < this.heap.length &&
            this.compare(this.heap[left], this.heap[smallest]) < 0) {
            smallest = left;
        }
        if (right < this.heap.length &&
            this.compare(this.heap[right], this.heap[smallest]) < 0) {
            smallest = right;
        }
        if (smallest !== index) {
            this.swap(index, smallest);
            this.heapifyDown(smallest);
        }
    };
    MinHeap.prototype.swap = function (i, j) {
        var _a;
        _a = [this.heap[j], this.heap[i]], this.heap[i] = _a[0], this.heap[j] = _a[1];
    };
    return MinHeap;
}());
exports.MinHeap = MinHeap;
