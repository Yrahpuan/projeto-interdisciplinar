"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ControleDePrioridade = void 0;
var informacoesDeRisco_1 = require("./informacoesDeRisco");
var Heap_1 = require("./Heap");
var ControleDePrioridade = /** @class */ (function () {
    function ControleDePrioridade() {
        this.heaps = [];
        for (var risco = 0; risco <= 4; risco++) {
            this.heaps[risco] = new Heap_1.MinHeap();
        }
    }
    ControleDePrioridade.prototype.adicionar = function (modelo) {
        this.heaps[modelo.risco].insert(modelo);
    };
    ControleDePrioridade.prototype.proximo = function () {
        var candidato;
        var menorTempoRestante = Infinity;
        for (var _i = 0, _a = this.heaps; _i < _a.length; _i++) {
            var fila = _a[_i];
            var atual = fila.peek();
            if (atual) {
                var agora = new Date();
                var tempoDecorrido = (agora.getTime() - atual.horarioDeChegada.getTime()) / 60000;
                var restante = informacoesDeRisco_1.LimiteDeTempo[atual.risco] - tempoDecorrido;
                if (restante < menorTempoRestante) {
                    menorTempoRestante = restante;
                    candidato = atual;
                }
            }
        }
        if (!candidato)
            return undefined;
        return this.heaps[candidato.risco].extractMin();
    };
    ControleDePrioridade.prototype.temElementos = function () {
        return this.heaps.some(function (fila) { return !fila.isEmpty(); });
    };
    return ControleDePrioridade;
}());
exports.ControleDePrioridade = ControleDePrioridade;
