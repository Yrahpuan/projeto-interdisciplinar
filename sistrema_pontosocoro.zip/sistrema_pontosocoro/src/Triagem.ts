import * as fs from "fs";
import { ModeloPaciente } from "./Paciente";
import { NivelsDeRisco, LimiteDeSenhas } from "./informacoesDeRisco";
import { ControleDePrioridade } from "./ControleDePrioridade";

export type ModeloDeDadosDaTriagem = {
    id: number;
    triagens: {
        risco: NivelsDeRisco;
        sintomas: string;
        descricao: string;
        data: Date;
    }[];
};

export class Triagem {
    private filaDaTriagem: ModeloPaciente[] = [];

    constructor() {
        this.carregarFilaDaTriagem();
    }

    private carregarFilaDaTriagem(): void {
        this.filaDaTriagem = this.carregarJSON("./database/pacientesParaTriagem.json");
    }

    private salvarFilaDaTriagem(): void {
        this.salvarJSON("./database/pacientesParaTriagem.json", this.filaDaTriagem);
    }

    registrarTriagem(idPaciente: number, risco: NivelsDeRisco, sintomas: string, descricao: string): void {
        const registros: ModeloDeDadosDaTriagem[] = this.carregarJSON("./database/registroDeTriagens.json");

        const registro = registros.find(t => t.id === idPaciente);

        const novaTriagem = {
            risco,
            sintomas,
            descricao,
            data: new Date()
        };

        if (registro) {
            registro.triagens.push(novaTriagem);
        } else {
            registros.push({ id: idPaciente, triagens: [novaTriagem] });
        }

        this.salvarJSON("./database/registroDeTriagens.json", registros);
    }

    porNaFilaDeEspera(risco: NivelsDeRisco, controle: ControleDePrioridade): void {
        const paciente = this.filaDaTriagem.shift();
        if (!paciente) return;

        const heap = controle.heaps[risco];
        const senha = heap.isEmpty()
            ? LimiteDeSenhas[risco - 1] + 1
            : heap.peek()!.senha + 1;

        heap.insert({
            id: paciente.id,
            senha,
            risco,
            horarioDeChegada: new Date()
        });

        this.salvarFilaDaTriagem();
    }

    private carregarJSON(path: string): any[] {
        if (!fs.existsSync(path)) return [];
        return JSON.parse(fs.readFileSync(path, "utf-8"));
    }

    private salvarJSON(path: string, data: any): void {
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
    }
}
