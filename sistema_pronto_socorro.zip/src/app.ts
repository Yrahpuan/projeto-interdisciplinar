import express from 'express';
import fs from 'fs';
import path from 'path';
import bodyParser from 'body-parser';
import { Cadastro } from './Cadastro';
import { Triagem } from './Triagem';
import { NiveisDeRisco } from './informacoesDeRisco';
import { ControleDePrioridade} from './ControleDePrioridade';
import { ModeloPaciente, ModeloFilaDePrioridade } from './models';
import { carregarJSON, pacientesDatabaseFileName, procurarPacientePorCpf, procurarPacientePorId } from './utils';

const app = express();
const PORT = 3001;
const publicDir = path.join(__dirname, '../public');

app.use(bodyParser.json());
app.use(express.static(publicDir));

const controle = new ControleDePrioridade();
const cadastro = new Cadastro();

const pacientesPath = path.join('./databases/registroDePacientes.json');
const triagensPath = path.join('./databases/registroDeTriagens.json');

app.post('/cadastro', (req, res) => {
  console.log("🆕 Recebendo cadastro:", req.body);
  const { nome, idade, cpf } = req.body;
  const id = carregarJSON(pacientesDatabaseFileName).length + 1;

  let paciente = procurarPacientePorCpf(cpf);
  if(paciente === undefined){
    paciente = cadastro.cadastrarPaciente(id, cpf, nome, idade);
  }

  if (paciente) {
    res.json({ id });
  } else {
    res.status(400).json({ erro: "Paciente com esse CPF já existe" });
  }
});

app.post('/pesquisa', (req, res) => {
  const { id, cpf } = req.body;

  let pacientePorId = procurarPacientePorId(id);

  if (pacientePorId) {
    if(id === pacientePorId.id){
      const message = `o id: ${id} é referênte ao cadastro de ${pacientePorId.nome}`;
      res.json({ message });
    }
  }

  let pacientePorCpf = procurarPacientePorCpf(cpf);

  if (pacientePorCpf) {
    if(cpf === pacientePorCpf.cpf){
      const message = `o cpf: ${cpf} é referênte ao cadastro de ${pacientePorCpf.nome}`;
      res.json({ message });
    }
  }



  //if(pacientePorId === undefined && pacientePorCpf === undefined){
    res.json({message: "Não há registro de pacientes com esses dados"});
    res.status(400).json({ erro: "não existe paciente cadastrado com esses dados" });
  //}
});

app.post('/triagem', (req, res) => {
  const { id, risco, sintomas, descricao } = req.body;
  const triagem = new Triagem();
  let nivelDeRisco = NiveisDeRisco.vermelho;
  switch(risco){
    case 1:
      nivelDeRisco = NiveisDeRisco.laranja;
      break;
    case 2:
      nivelDeRisco = NiveisDeRisco.amarelo;
      break;
    case 3:
      nivelDeRisco = NiveisDeRisco.verde;
      break;
    case 4:
      nivelDeRisco = NiveisDeRisco.azul;
      break;
  }
  triagem.registrarTriagem(id, nivelDeRisco, sintomas, descricao);
  triagem.porNaFilaDeEspera(id, nivelDeRisco);
  res.json({ ok: true });
});

app.get('/fila', (req, res) => {
  const heaps = controle.getHeaps();

  const filas: ModeloFilaDePrioridade[] = [];

  heaps.forEach(heap => {
    if(!heap.taVazio()){
      heap.heap.forEach(paciente => {
        filas.push({
          id: paciente.id,
          senha: paciente.senha,
          risco: paciente.risco,
          horarioDeChegada: paciente.horarioDeChegada,
          horarioMaximoDeEspera: paciente.horarioMaximoDeEspera
        });
      });
    }
  });
  //console.log(filas);

  res.json(filas);
});

app.post('/fila/proximo', (req, res) => {
  const proximo = controle.proximo();
  const jsonDB = fs.readFileSync(pacientesPath).toString();
  const pacienteDB: ModeloPaciente[] = JSON.parse(jsonDB);
  console.log(pacienteDB);
  if(proximo){
    pacienteDB.forEach((paciente) => {
      if(paciente.id === proximo.id){
        res.json({id: paciente.id, nome: paciente.nome});
      }
    });
  }
  console.log(proximo);
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});