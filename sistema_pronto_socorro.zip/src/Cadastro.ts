import { carregarJSON, pacientesDatabaseFileName, salvarJSON } from "./utils";
import { ModeloPaciente } from "./models";

export class Cadastro {
    private baseDeDados: ModeloPaciente[] = [];

    constructor() {

    }
    cadastrarPaciente(id: number, cpf: string, nome: string, idade: number): ModeloPaciente | undefined {
        this.baseDeDados = carregarJSON(pacientesDatabaseFileName);
        if (this.baseDeDados.some(p => p.cpf === cpf)) {
            console.warn("Não é permitido cadastrar duas pessoas com o mesmo CPF.");
            return;
        }

        const novoPaciente: ModeloPaciente = { id, cpf, nome, idade };
        this.baseDeDados.push(novoPaciente);

        salvarJSON(pacientesDatabaseFileName, this.baseDeDados);
        return novoPaciente;
    }
}
