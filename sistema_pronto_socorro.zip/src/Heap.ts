import { ModeloFilaDePrioridade } from "./models";
import { LimiteDeTempo, NiveisDeRisco } from "./informacoesDeRisco";

export class MinHeap {
  readonly heap: ModeloFilaDePrioridade[] = [];

  private parente(indice: number): number {
    return Math.floor((indice - 1) / 2);
  }

  private filhoEsquerdo(indice: number): number {
    return 2 * indice + 1;
  }

  private filhoDireito(indice: number): number {
    return 2 * indice + 2;
  }
  
  public mostrarConteudo(): void {
    console.log("Heap:");
    this.heap.forEach((item, indice) => {
      console.log(
        `  [${indice}] ID: ${item.id}, Senha: ${item.senha}, Risco: ${NiveisDeRisco[item.risco]}, Chegada: ${item.horarioDeChegada.toLocaleString()}, MaximoDeEspera: ${item.horarioMaximoDeEspera.toLocaleString()}`
      );
    });
  }
  

  private comparar(a: ModeloFilaDePrioridade, b: ModeloFilaDePrioridade): number {
    const agora = new Date();
  
    const decorridoA = (agora.getTime() - a.horarioDeChegada.getTime()) / 60000;
    const restanteA = LimiteDeTempo[a.risco] - decorridoA;
  
    const decorridoB = (agora.getTime() - b.horarioDeChegada.getTime()) / 60000;
    const restanteB = LimiteDeTempo[b.risco] - decorridoB;
  
    if (restanteA !== restanteB) {
      return restanteA - restanteB;
    }
  
    if (a.horarioDeChegada.getTime() !== b.horarioDeChegada.getTime()) {
      return a.horarioDeChegada.getTime() - b.horarioDeChegada.getTime();
    }

    return a.senha - b.senha;
  }  

  inserir(valor: ModeloFilaDePrioridade): void {
    this.heap.push(valor);
    this.heapificarCima(this.heap.length - 1);
  }

  retirarMenor(): ModeloFilaDePrioridade | undefined {
    if (this.taVazio()) return undefined;
    if (this.heap.length === 1) return this.heap.pop();

    const min = this.heap[0];
    this.heap[0] = this.heap.pop()!;
    this.heapificarBaixo(0);
    return min;
  }

  olhar(): ModeloFilaDePrioridade | undefined {
    return this.heap[0];
  }

  taVazio(): boolean {
    return this.heap.length === 0;
  }

  private heapificarCima(indice: number): void {
    while (
      indice > 0 &&
      this.comparar(this.heap[indice], this.heap[this.parente(indice)]) < 0
    ) {
      this.trocar(indice, this.parente(indice));
      indice = this.parente(indice);
    }
  }

  private heapificarBaixo(indice: number): void {
    let menor = indice;
    const esquerdo = this.filhoEsquerdo(indice);
    const direito = this.filhoDireito(indice);

    if (
      esquerdo < this.heap.length &&
      this.comparar(this.heap[esquerdo], this.heap[menor]) < 0
    ) {
      menor = esquerdo;
    }

    if (
      direito < this.heap.length &&
      this.comparar(this.heap[direito], this.heap[menor]) < 0
    ) {
      menor = direito;
    }

    if (menor !== indice) {
      this.trocar(indice, menor);
      this.heapificarBaixo(menor);
    }
  }

  private trocar(i: number, j: number): void {
    [this.heap[i], this.heap[j]] = [this.heap[j], this.heap[i]];
  }
}
