import { ModeloPaciente } from "./models";

export class Paciente {
    constructor(
        protected readonly id: number,
        protected readonly cpf: string,
        protected readonly nome: string,
        protected readonly idade: number
    ) {}

    getId(): number {
        return this.id;
    }

    getCpf(): string {
        return this.cpf;
    }

    toJSON(): ModeloPaciente {
        return {
            id: this.id,
            cpf: this.cpf,
            nome: this.nome,
            idade: this.idade
        };
    }

    static fromModel(model: ModeloPaciente): Paciente {
        return new Paciente(model.id, model.cpf, model.nome, model.idade);
    }
}
