import { NiveisDeRisco, LimiteDeSenhas, LimiteDeTempo } from "./informacoesDeRisco";
import { carregarJSON, filaFileName, registroTriagemFileName, salvarJSON } from "./utils";
import { ModeloDeDadosDaTriagem, ModeloFilaDePrioridade} from "./models";

export class Triagem {
    
    constructor() {
        
    }

    registrarTriagem(id: number, risco: NiveisDeRisco, sintomas: string, descricao: string): void {
        const registros: ModeloDeDadosDaTriagem[] = carregarJSON(registroTriagemFileName);

        const registro = registros.find(t => t.id === id);

        const novaTriagem = {
            risco: NiveisDeRisco[risco],
            sintomas,
            descricao,
            data: new Date()
        };

        if (registro) {
            registro.triagensFeitas.push(novaTriagem);
        } else {
            registros.push({ id: id, triagensFeitas: [novaTriagem] });
        }

        salvarJSON(registroTriagemFileName, registros);
    }

    porNaFilaDeEspera(id: number, risco: NiveisDeRisco): void {
        const fila = carregarJSON(filaFileName);
        console.log("a", fila);
        const senha = fila[risco].length === 0 ? LimiteDeSenhas[risco - 1] + 1 : fila[risco][fila[risco].length - 1].senha + 1;

        const agora = new Date();
        const maximoDeEspera = new Date(agora.getTime() + LimiteDeTempo[risco] * 60 * 1000);

        const paraFila: ModeloFilaDePrioridade = {
            id,
            senha,
            risco,
            horarioDeChegada: new Date(),
            horarioMaximoDeEspera: maximoDeEspera
        }

        fila[risco].push(paraFila);console.log("b", fila)


        salvarJSON(filaFileName, fila);
    }
}
