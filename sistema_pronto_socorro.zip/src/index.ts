import { Cadastro } from "./Cadastro";
import { Triagem } from "./Triagem";
import { ControleDePrioridade } from "./ControleDePrioridade";
import { NiveisDeRisco } from "./informacoesDeRisco";
import { procurarPacientePorCpf, procurarPacientePorId } from "./utils";

const cadastro = new Cadastro();
const triagem = new Triagem();
const controle = new ControleDePrioridade();

try {
    // 1. Cadastrar um novo paciente
    const novoPaciente = procurarPacientePorId(1)!;
    console.log("Paciente cadastrado:", novoPaciente);

    const paciente = procurarPacientePorId(2)!;
    console.log("paciente", paciente);

    // 2. Enviar para triagem
    //cadastro.mandarParaTriagem(novoPaciente);
    //console.log("Paciente enviado para triagem");

    // 3. Registrar a triagem
    triagem.registrarTriagem(
        novoPaciente.id,
        NiveisDeRisco.verde,
        "Febre, dor de cabeça",
        "Paciente relata febre persistente e dor de cabeça intensa."
    );
    console.log("Triagem registrada");
    triagem.registrarTriagem(
        paciente.id,
        NiveisDeRisco.azul,
        "Febre, dor de cabeça",
        "Paciente relata febre persistente e dor de cabeça intensa."
    );
    console.log("Triagem registrada");

    // 4. Inserir na fila de espera correspondente
    triagem.porNaFilaDeEspera(novoPaciente.id, NiveisDeRisco.verde);
    triagem.porNaFilaDeEspera(paciente.id, NiveisDeRisco.azul);
    console.log("Paciente colocado na fila de espera");
} catch (erro) {
    console.error("Erro durante o processo:", erro);
}

const h = controle.getHeaps();
const p = h[4].extractMin();
if(p){
    const agora = new Date()
    p.horarioMaximoDeEspera = new Date(agora.getTime() + (-150 * 60 * 1000));
    h[4].insert(p);
}

//console.log(controle.proximo());

// Mostrar o conteúdo atual das filas
controle.mostrarFilas();

for(const heap of controle.getHeaps()){
    console.log("b", heap.peek());
}

console.log(controle.proximo());
console.log(controle.proximo());