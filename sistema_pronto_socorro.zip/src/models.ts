import { NiveisDeRisco } from "./informacoesDeRisco";

export type ModeloPaciente = {
    id: number;
    cpf: string;
    nome: string;
    idade: number;
};

export type ModeloDeDadosDaTriagem = {
    id: number;
    triagensFeitas: {
        risco: string;
        sintomas: string;
        descricao: string;
        data: Date;
    }[];
};

export type ModeloFilaDePrioridade = {
    id: number;
    senha: number;
    risco: NiveisDeRisco;
    horarioDeChegada: Date;
    horarioMaximoDeEspera: Date;
};