import { NiveisDeRisco, LimiteDeTempo } from "./informacoesDeRisco";
import { MinHeap } from "./Heap";
import { ModeloFilaDePrioridade } from "./models";
import { carregarJSON, filaFileName, salvarJSON } from "./utils";

export class ControleDePrioridade {
  private heaps: MinHeap[] = [];

  constructor() {
    for (let risco = 0; risco <= 4; risco++) {
      this.heaps[risco] = new MinHeap();
    }
  }
  carregarFilas() {
    this.heaps = [];
    const filas = carregarJSON(filaFileName);

    for (let risco = 0; risco < filas.length; risco++) {
      const filaDoRisco = filas[risco];

      if (filaDoRisco) {
        this.heaps[risco] = new MinHeap();

        for (const paciente of filaDoRisco) {
          this.heaps[risco].inserir({
            id: paciente.id,
            senha: paciente.senha,
            risco: paciente.risco,
            horarioDeChegada: new Date(paciente.horarioDeChegada),
            horarioMaximoDeEspera: new Date(paciente.horarioMaximoDeEspera),
          });
        }
      }
    }
  }

  adicionar(modelo: ModeloFilaDePrioridade): void {
    this.carregarFilas();
    const filas = carregarJSON(filaFileName);

    this.heaps[modelo.risco].inserir(modelo);
    filas[modelo.risco].push(modelo);
    salvarJSON(filaFileName, filas);
  }

  proximo(): ModeloFilaDePrioridade | undefined {
    const filas = carregarJSON(filaFileName);
    this.carregarFilas();
    let candidato: ModeloFilaDePrioridade | undefined;
    let menorTempoRestante = Infinity;

    for (const fila of this.heaps) {
      let atual: ModeloFilaDePrioridade | undefined;
      if(fila){
        atual = fila.olhar()!;
      }else{
        atual = undefined;
    }
      
      if (atual) {
        const agora = new Date();
        const tempoDecorrido = (agora.getTime() - atual.horarioDeChegada.getTime()) / 60000;
        const restante = LimiteDeTempo[atual.risco] - tempoDecorrido;

        if (restante < menorTempoRestante) {
          menorTempoRestante = restante;
          candidato = atual;
        }
      }
    }

    if (!candidato) return undefined;

    const proximo = this.heaps[candidato.risco].retirarMenor();
    filas[candidato.risco].shift();
    salvarJSON(filaFileName, filas);
    return proximo;
  }

  temElementos(): boolean {
    return this.heaps.some(fila => !fila.taVazio());
  }

  mostrarFilas(): void {
    this.carregarFilas();
    console.log("\n=== FILAS DE PRIORIDADE POR RISCO ===");
    Object.entries(this.heaps).forEach(([risco, heap]) => {
      console.log(`\nFila ${NiveisDeRisco[parseInt(risco)]}:`);
      heap.mostrarConteudo();
    });
  }
  getHeaps(){
    this.carregarFilas();
    return this.heaps;
  }
}

